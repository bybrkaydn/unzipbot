from pyrogram import Client, filters, enums
import glob
import sys
import os
import shutil
import time
from pyunpack import Archive
import pathlib
from tkinter import Tcl
import speedtest


sys.setrecursionlimit(7000)

    
bot = Client("Echo-bot",
api_id=1971017,
api_hash="d2648dee8c9dc2c93a4ee1d31a6fb30b",
bot_token="5707977044:AAF2nkMXwgmniBMU6sYrJPBUeWXJigERqRo")

@bot.on_message(filters.document)
def echobot(client,message):
    print(message.document.mime_type)

    if message.document.mime_type == "application/x-rar-compressed" or message.document.mime_type == "application/vnd.rar" or message.document.mime_type =="application/rar":
        text = bot.send_message(message.from_user.id,str(message.document.file_name)+" indiriliyor...")
        bot.download_media(message.document.file_id, "./rar/"+str(message.document.file_name))
        bot.edit_message_text(message.from_user.id,text.id,str(message.document.file_name)+" çıkarılıyor...")
        
        Archive("./rar/"+str(message.document.file_name)).extractall('./unrar')

        bot.edit_message_text(message.from_user.id,text.id,str(message.document.file_name)+" yüklemek için hazırlanıyor...")

        types = [".pdf",".epub",".mp4",".txt"]
        for typ in types:
            for root, dirs, files in os.walk("./unrar"):
                for file in files:
                    if file.endswith(typ):
                        shutil.move(os.path.join(root, file), "./file/"+file)

        bot.edit_message_text(message.from_user.id,text.id,str(message.document.file_name)+" yükleniyor...")
        dirs = os.listdir("./file")
        im_list = Tcl().call('lsort', '-dict', dirs)
        for doc in im_list:
            tur = str(pathlib.Path("./file/"+doc).suffixes)
            if tur == "['.mp4']":
                bot.send_video(message.from_user.id,"./file/"+doc, caption=doc)
                time.sleep(2)
            else:
                bot.send_document(message.from_user.id,"./file/"+doc, caption=doc)
                time.sleep(2)

        bot.edit_message_text(message.from_user.id,text.id,str(message.document.file_name)+" Yükleme tamamlandı")
        folders = ['./file/*','./rar/*']
        for fol in folders:
            files = glob.glob(fol)
            for f in files:
                os.remove(f)        

    if message.document.mime_type == "application/zip":
        text = bot.send_message(message.from_user.id,str(message.document.file_name)+" indiriliyor...")
        bot.download_media(message.document.file_id, "./zip/"+str(message.document.file_name))
        bot.edit_message_text(message.from_user.id,text.id,str(message.document.file_name)+" çıkarılıyor...")
        Archive("./zip/"+str(message.document.file_name)).extractall('./unzip')
        bot.edit_message_text(message.from_user.id,text.id,str(message.document.file_name)+" yüklemek için hazırlanıyor...")

        types = [".pdf",".epub",".mp4",".txt"]
        for typ in types:
            for root, dirs, files in os.walk("./unzip"):
                for file in files:
                    if file.endswith(typ):
                        shutil.move(os.path.join(root, file), "./file/"+file)

        bot.edit_message_text(message.from_user.id,text.id,str(message.document.file_name)+" yükleniyor...")
        dirs = os.listdir("./file")
        im_list = Tcl().call('lsort', '-dict', dirs)
        for doc in im_list:
            tur = str(pathlib.Path("./file/"+doc).suffixes)
            if tur == "['.mp4']":
                bot.send_video(message.from_user.id,"./file/"+doc, caption=doc)
                time.sleep(2)
            else:
                bot.send_document(message.from_user.id,"./file/"+doc, caption=doc)
                time.sleep(2)

        bot.edit_message_text(message.from_user.id,text.id,str(message.document.file_name)+" Yükleme tamamlandı")

        folders = ['./file/*','./zip/*']
        for fol in folders:
            files = glob.glob(fol)
            for f in files:
                os.remove(f)


@bot.on_message(filters.command(commands=['speedtest']) & filters.private)
def welcome(client,message):
        test = speedtest.Speedtest()
        message1=bot.send_message(message.from_user.id,"💫 Hız testi başlatıldı...",parse_mode=enums.ParseMode.MARKDOWN)  
        test.get_servers() 
        best = test.get_best_server() 
        download_result = test.download()
        upload_result = test.upload()
        ping_result = test.results.ping
        bot.edit_message_text(message.from_user.id,message1.id,f"**Konum:** {best['country']}\n"+
                                                                       f"**Download speed:** {download_result / 1024 / 1024:.2f} Mbit/s\n"+
                                                                       f"**Upload speed:** {upload_result / 1024 / 1024:.2f} Mbit/s\n"+
                                                                       F"**Ping**: {ping_result:.2f} ms",parse_mode=enums.ParseMode.MARKDOWN)  


bot.run()

